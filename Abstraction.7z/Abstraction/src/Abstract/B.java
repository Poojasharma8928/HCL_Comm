
class B extends Marks{

   String Std_Name;
   int Marks1, Marks2, Marks3, Marks4;

   public B( String Name , int M1, int M2, int M3, int M4){
	   
	   Std_Name = Name;

       Marks1=M1;

       Marks2=M2;

       Marks3=M3;

       Marks4=M4;

  }
   
   	public float getPercentage() {
   		
   		
   		System.out.println("Result for Student " +Std_Name);
   		float total=((Marks1+Marks2+Marks3+Marks4)/(float)400)*100;

        return total;
	}

}