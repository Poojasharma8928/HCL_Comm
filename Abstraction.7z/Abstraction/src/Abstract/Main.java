
public class Main {

	public static void main(String[] args) {

	    A Obj1 = new A("Pooja" , 90, 80, 100);
	    
	

	       System.out.println(Obj1.getPercentage());

	       B Obj2 = new B("Janvi" , 80, 75, 60, 82);

	       System.out.println(Obj2.getPercentage());

	}

	}

