abstract class  Marks {

   public abstract float getPercentage();

}