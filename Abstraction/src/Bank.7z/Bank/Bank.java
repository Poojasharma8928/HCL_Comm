package Bank;

public interface Bank {
	
	public void getCustomerName();
	public void getAccountNumber();
	public void getAccountType();
	public void getBalance();
		
}
