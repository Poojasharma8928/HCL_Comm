package Bank;

public class Main {
public static void main(String[] args) {
	 BankA obj1 = new BankA("Pooja",  529 , "Savings" ,  5000);
	 obj1.getCustomerName();
	 obj1.getAccountNumber();
	 obj1.getAccountType();
	 obj1.getBalance();
	 
	System.out.println("_____________________"); 
	
	 BankB obj2 = new BankB("Janvi",  777 , "Current" ,  7000);
	 obj2.getCustomerName();
	 obj2.getAccountNumber();
	 obj2.getAccountType();
	 obj2.getBalance();
	 
	 System.out.println("_____________________"); 
	 
	 BankA obj3 = new BankA("Priya",  927 , "Loan" ,  50000);
	 obj3.getCustomerName();
	 obj3.getAccountNumber();
	 obj3.getAccountType();
	 obj3.getBalance();
	 
	 
	 
	 
}
}
