abstract class Abstract
{
	abstract void Intern();
	abstract void Associate_Consultant();
	abstract void Technical_Consultant();
}
