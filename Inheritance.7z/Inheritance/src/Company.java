interface Company{
	String Comp_name="PRFT Inc";}