class Designation extends Abstract 
  {
	  void Intern()
	  {
		  System.out.println("Designation is Intern");
	  }
	  void Associate_Consultant()
	  {
		  System.out.println("Designation is Associate Technical Consultant");
	  }
	  void Technical_Consultant()
	  {
		  System.out.println("Designation is Technical Consultatnt");
	  }
	  
	  
  }