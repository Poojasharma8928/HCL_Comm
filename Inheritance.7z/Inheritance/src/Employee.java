public class Employee {

	public static void main(String[] args)
	{
		Department obj = new Department();
		obj.AEM(); 
		
		obj.JAVA();
		
		obj.PHP();
        
	}

}