public interface Emp 
{
public void getId();
public void getName();
public void getDesignation();
}